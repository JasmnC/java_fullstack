package com.example.demo.model.document;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.time.Instant;
import java.util.Map;

/**
 * AuditTrail - MongoDB Document
 *
 * Immutable audit records for compliance, security, and regulatory requirements.
 * Tracks all data modifications with before/after snapshots.
 *
 * Use Cases:
 * - Regulatory compliance (GDPR, HIPAA, SOX)
 * - Security auditing and forensics
 * - Data change tracking and history
 * - Accountability and non-repudiation
 * - Root cause analysis for data issues
 *
 * Why MongoDB:
 * - Immutable records (write-once, read-many)
 * - Complex nested structures (before/after snapshots)
 * - Long retention periods without affecting PostgreSQL
 * - Fast writes during high-traffic operations
 * - Time-based queries and retention policies
 */
@Document(collection = "audit_trails")
@CompoundIndexes({
        @CompoundIndex(name = "user_entity_idx", def = "{'userId': 1, 'targetEntity': 1, 'timestamp': -1}"),
        @CompoundIndex(name = "entity_time_idx", def = "{'targetEntity': 1, 'targetEntityId': 1, 'timestamp': -1}")
})
public class AuditTrail implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id; // MongoDB ObjectId

    /**
     * User who performed the action
     * Reference to PostgreSQL User.id
     */
    @Indexed
    private Long userId;

    /**
     * Type of entity that was modified
     * Examples: "User", "Order", "Product"
     */
    @Indexed
    private String targetEntity;

    /**
     * ID of the specific entity that was modified
     * Example: User ID 123, Order ID 456
     */
    private Long targetEntityId;

    /**
     * Operation performed
     * Values: CREATE, UPDATE, DELETE, LOGIN, LOGOUT
     */
    @Indexed
    private String operation;

    /**
     * When the operation occurred
     * Indexed for time-range queries
     */
    @Indexed
    @CreatedDate
    private Instant timestamp;

    /**
     * Client IP address
     */
    private String ipAddress;

    /**
     * User agent string
     */
    private String userAgent;

    /**
     * Changes made during this operation
     * Contains before/after snapshots of modified fields
     */
    private ChangeSet changeSet;

    /**
     * Reason for the change (optional)
     * User-provided or system-generated explanation
     */
    private String reason;

    /**
     * Compliance and regulatory flags
     */
    private ComplianceFlags complianceFlags;

    /**
     * Additional context or metadata
     */
    private Map<String, Object> metadata;

    // Nested Classes

    public static class ChangeSet implements Serializable {
        private Map<String, Object> before; // State before change
        private Map<String, Object> after;  // State after change

        public ChangeSet() {
        }

        public ChangeSet(Map<String, Object> before, Map<String, Object> after) {
            this.before = before;
            this.after = after;
        }

        // Getters and Setters

        public Map<String, Object> getBefore() {
            return before;
        }

        public void setBefore(Map<String, Object> before) {
            this.before = before;
        }

        public Map<String, Object> getAfter() {
            return after;
        }

        public void setAfter(Map<String, Object> after) {
            this.after = after;
        }
    }

    public static class ComplianceFlags implements Serializable {
        private Boolean gdprCompliant;
        private Boolean dataRetentionApplies;
        private String regulatoryFramework; // "GDPR", "HIPAA", "SOX", etc.
        private String retentionPeriod;      // "7years", "indefinite", etc.

        public ComplianceFlags() {
        }

        // Getters and Setters

        public Boolean getGdprCompliant() {
            return gdprCompliant;
        }

        public void setGdprCompliant(Boolean gdprCompliant) {
            this.gdprCompliant = gdprCompliant;
        }

        public Boolean getDataRetentionApplies() {
            return dataRetentionApplies;
        }

        public void setDataRetentionApplies(Boolean dataRetentionApplies) {
            this.dataRetentionApplies = dataRetentionApplies;
        }

        public String getRegulatoryFramework() {
            return regulatoryFramework;
        }

        public void setRegulatoryFramework(String regulatoryFramework) {
            this.regulatoryFramework = regulatoryFramework;
        }

        public String getRetentionPeriod() {
            return retentionPeriod;
        }

        public void setRetentionPeriod(String retentionPeriod) {
            this.retentionPeriod = retentionPeriod;
        }
    }

    // Constructors

    public AuditTrail() {
    }

    public AuditTrail(Long userId, String targetEntity, Long targetEntityId, String operation) {
        this.userId = userId;
        this.targetEntity = targetEntity;
        this.targetEntityId = targetEntityId;
        this.operation = operation;
        this.timestamp = Instant.now();
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getTargetEntity() {
        return targetEntity;
    }

    public void setTargetEntity(String targetEntity) {
        this.targetEntity = targetEntity;
    }

    public Long getTargetEntityId() {
        return targetEntityId;
    }

    public void setTargetEntityId(Long targetEntityId) {
        this.targetEntityId = targetEntityId;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Instant timestamp) {
        this.timestamp = timestamp;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public ChangeSet getChangeSet() {
        return changeSet;
    }

    public void setChangeSet(ChangeSet changeSet) {
        this.changeSet = changeSet;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public ComplianceFlags getComplianceFlags() {
        return complianceFlags;
    }

    public void setComplianceFlags(ComplianceFlags complianceFlags) {
        this.complianceFlags = complianceFlags;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
}
