package com.example.demo.model.document;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.time.Instant;
import java.util.Map;

/**
 * UserActivityLog - MongoDB Document
 *
 * Tracks user actions, API calls, and behavioral analytics.
 * This is a high-volume, time-series collection stored in MongoDB for performance.
 *
 * Use Cases:
 * - User behavior analytics
 * - API usage monitoring
 * - Login/logout tracking
 * - Performance metrics per endpoint
 * - Cache hit/miss statistics
 *
 * Why MongoDB:
 * - High write volume (every user action)
 * - Time-series data (chronological logs)
 * - Flexible schema (different activities have different metadata)
 * - Fast inserts without blocking PostgreSQL
 * - Append-only pattern (no updates)
 */
@Document(collection = "user_activity_logs")
public class UserActivityLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id; // MongoDB ObjectId

    /**
     * Reference to PostgreSQL User.id
     * Indexed for fast queries by user
     */
    @Indexed
    private Long userId;

    /**
     * Type of activity performed
     * Examples: LOGIN, LOGOUT, API_CALL, UPDATE_PROFILE, DELETE_ACCOUNT
     */
    @Indexed
    private String activityType;

    /**
     * API endpoint accessed (if applicable)
     * Example: "/v1/api/jpa/user/123"
     */
    private String endpoint;

    /**
     * HTTP method used
     * Example: GET, POST, PUT, DELETE
     */
    private String method;

    /**
     * Client IP address
     */
    private String ipAddress;

    /**
     * User agent string
     */
    private String userAgent;

    /**
     * Request duration in milliseconds
     */
    private Long requestDurationMs;

    /**
     * HTTP status code
     */
    private Integer statusCode;

    /**
     * When the activity occurred
     * Indexed for time-range queries
     */
    @Indexed
    @CreatedDate
    private Instant timestamp;

    /**
     * Additional flexible metadata
     * Can contain any activity-specific data
     * Examples: queryParams, responseSize, cacheHit, errorDetails
     */
    private Map<String, Object> metadata;

    // Constructors

    public UserActivityLog() {
    }

    public UserActivityLog(Long userId, String activityType) {
        this.userId = userId;
        this.activityType = activityType;
        this.timestamp = Instant.now();
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public Long getRequestDurationMs() {
        return requestDurationMs;
    }

    public void setRequestDurationMs(Long requestDurationMs) {
        this.requestDurationMs = requestDurationMs;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Instant timestamp) {
        this.timestamp = timestamp;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
}
