package com.example.demo.exception;

import jakarta.persistence.OptimisticLockException;
import jakarta.persistence.PessimisticLockException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Global exception handler for handling JPA locking exceptions across all controllers.
 * Provides consistent error responses for optimistic and pessimistic locking failures.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handles OptimisticLockException - thrown when a version conflict occurs during update.
     * This happens when two transactions try to update the same entity concurrently.
     *
     * @param ex The OptimisticLockException
     * @param request The web request
     * @return ResponseEntity with 409 Conflict status and error details
     */
    @ExceptionHandler(OptimisticLockException.class)
    public ResponseEntity<Map<String, Object>> handleOptimisticLockException(
            OptimisticLockException ex,
            WebRequest request) {

        logger.error("Optimistic lock exception occurred: {}", ex.getMessage(), ex);

        Map<String, Object> errorDetails = new HashMap<>();
        errorDetails.put("timestamp", LocalDateTime.now());
        errorDetails.put("status", HttpStatus.CONFLICT.value());
        errorDetails.put("error", "Conflict");
        errorDetails.put("message", "The resource was modified by another user. Please refresh and try again.");
        errorDetails.put("type", "OptimisticLockException");
        errorDetails.put("path", request.getDescription(false).replace("uri=", ""));

        return new ResponseEntity<>(errorDetails, HttpStatus.CONFLICT);
    }

    /**
     * Handles PessimisticLockException - thrown when a pessimistic lock cannot be acquired.
     * This happens when a row is already locked by another transaction.
     *
     * @param ex The PessimisticLockException
     * @param request The web request
     * @return ResponseEntity with 409 Conflict status and error details
     */
    @ExceptionHandler(PessimisticLockException.class)
    public ResponseEntity<Map<String, Object>> handlePessimisticLockException(
            PessimisticLockException ex,
            WebRequest request) {

        logger.error("Pessimistic lock exception occurred: {}", ex.getMessage(), ex);

        Map<String, Object> errorDetails = new HashMap<>();
        errorDetails.put("timestamp", LocalDateTime.now());
        errorDetails.put("status", HttpStatus.CONFLICT.value());
        errorDetails.put("error", "Conflict");
        errorDetails.put("message", "The resource is currently locked by another process. Please try again in a moment.");
        errorDetails.put("type", "PessimisticLockException");
        errorDetails.put("path", request.getDescription(false).replace("uri=", ""));

        return new ResponseEntity<>(errorDetails, HttpStatus.CONFLICT);
    }

    /**
     * Handles CannotAcquireLockException - thrown when a lock cannot be acquired within the timeout period.
     * This is typically thrown by Spring Data JPA when pessimistic locking fails.
     *
     * @param ex The CannotAcquireLockException
     * @param request The web request
     * @return ResponseEntity with 409 Conflict status and error details
     */
    @ExceptionHandler(CannotAcquireLockException.class)
    public ResponseEntity<Map<String, Object>> handleCannotAcquireLockException(
            CannotAcquireLockException ex,
            WebRequest request) {

        logger.error("Cannot acquire lock exception occurred: {}", ex.getMessage(), ex);

        Map<String, Object> errorDetails = new HashMap<>();
        errorDetails.put("timestamp", LocalDateTime.now());
        errorDetails.put("status", HttpStatus.CONFLICT.value());
        errorDetails.put("error", "Conflict");
        errorDetails.put("message", "Unable to acquire lock on the resource. The resource may be in use by another transaction.");
        errorDetails.put("type", "CannotAcquireLockException");
        errorDetails.put("path", request.getDescription(false).replace("uri=", ""));

        return new ResponseEntity<>(errorDetails, HttpStatus.CONFLICT);
    }

    /**
     * Handles generic RuntimeException - fallback handler for unexpected errors.
     * This includes the custom exceptions thrown from the service layer after retry failures.
     *
     * @param ex The RuntimeException
     * @param request The web request
     * @return ResponseEntity with 500 Internal Server Error status
     */
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String, Object>> handleRuntimeException(
            RuntimeException ex,
            WebRequest request) {

        logger.error("Runtime exception occurred: {}", ex.getMessage(), ex);

        // Check if this is a wrapped locking exception from our retry recovery methods
        if (ex.getMessage() != null &&
            (ex.getMessage().contains("concurrent modification") ||
             ex.getMessage().contains("resource is locked"))) {

            Map<String, Object> errorDetails = new HashMap<>();
            errorDetails.put("timestamp", LocalDateTime.now());
            errorDetails.put("status", HttpStatus.CONFLICT.value());
            errorDetails.put("error", "Conflict");
            errorDetails.put("message", ex.getMessage());
            errorDetails.put("type", "LockingFailureAfterRetries");
            errorDetails.put("path", request.getDescription(false).replace("uri=", ""));

            return new ResponseEntity<>(errorDetails, HttpStatus.CONFLICT);
        }

        // Generic runtime exception
        Map<String, Object> errorDetails = new HashMap<>();
        errorDetails.put("timestamp", LocalDateTime.now());
        errorDetails.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
        errorDetails.put("error", "Internal Server Error");
        errorDetails.put("message", ex.getMessage());
        errorDetails.put("type", "RuntimeException");
        errorDetails.put("path", request.getDescription(false).replace("uri=", ""));

        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handles UserNotFoundException - custom exception for when a user is not found.
     *
     * @param ex The UserNotFoundException
     * @param request The web request
     * @return ResponseEntity with 404 Not Found status
     */
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleUserNotFoundException(
            UserNotFoundException ex,
            WebRequest request) {

        logger.error("User not found: {}", ex.getMessage());

        Map<String, Object> errorDetails = new HashMap<>();
        errorDetails.put("timestamp", LocalDateTime.now());
        errorDetails.put("status", HttpStatus.NOT_FOUND.value());
        errorDetails.put("error", "Not Found");
        errorDetails.put("message", ex.getMessage());
        errorDetails.put("type", "UserNotFoundException");
        errorDetails.put("path", request.getDescription(false).replace("uri=", ""));

        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }
}
