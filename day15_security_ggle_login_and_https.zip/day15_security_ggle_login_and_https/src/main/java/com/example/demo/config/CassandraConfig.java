package com.example.demo.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.cassandra.config.AbstractCassandraConfiguration;
import org.springframework.data.cassandra.config.SchemaAction;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;

@Profile("with-nosql")
@Configuration
@EnableCassandraRepositories(basePackages = "com.example.demo.repository.cassandra")
public class CassandraConfig extends AbstractCassandraConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(CassandraConfig.class);

    @Value("${spring.cassandra.keyspace-name}")
    private String keyspaceName;

    @Value("${spring.cassandra.contact-points}")
    private String contactPoints;

    @Value("${spring.cassandra.port}")
    private int port;

    @Value("${spring.cassandra.local-datacenter}")
    private String localDatacenter;

    @Override
    protected String getKeyspaceName() {
        logger.info("Cassandra keyspace: {}", keyspaceName);
        return keyspaceName;
    }

    @Override
    protected String getContactPoints() {
        logger.info("Cassandra contact points: {}", contactPoints);
        return contactPoints;
    }

    @Override
    protected int getPort() {
        logger.info("Cassandra port: {}", port);
        return port;
    }

    @Override
    protected String getLocalDataCenter() {
        logger.info("Cassandra local datacenter: {}", localDatacenter);
        return localDatacenter;
    }

    @Override
    public SchemaAction getSchemaAction() {
        // This will create tables if they don't exist
        return SchemaAction.CREATE_IF_NOT_EXISTS;
    }

    @Override
    public String[] getEntityBasePackages() {
        return new String[]{"com.example.demo.model.entity"};
    }
}
