package com.example.demo.repository.mongo;

import com.example.demo.model.document.UserPreferences;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * UserPreferencesRepository - Spring Data MongoDB Repository
 *
 * Provides database operations for UserPreferences documents.
 * One-to-one relationship with PostgreSQL User entity.
 *
 * Key Features:
 * - Unique index on userId ensures one preferences document per user
 * - Optimistic locking with @Version field prevents concurrent update conflicts
 * - Automatic timestamp tracking with @CreatedDate and @LastModifiedDate
 */
@Repository
public interface UserPreferencesRepository extends MongoRepository<UserPreferences, String> {

    /**
     * Find preferences for a specific user.
     * This is the primary lookup method.
     *
     * @param userId User ID from PostgreSQL
     * @return Optional containing preferences if found
     */
    Optional<UserPreferences> findByUserId(Long userId);

    /**
     * Check if preferences exist for a user.
     *
     * @param userId User ID
     * @return True if preferences exist
     */
    boolean existsByUserId(Long userId);

    /**
     * Delete preferences for a user.
     * Used when a user account is deleted.
     *
     * @param userId User ID
     * @return Number of documents deleted (should be 0 or 1)
     */
    long deleteByUserId(Long userId);

    /**
     * Find all users with a specific theme.
     * Analytics query to understand theme usage.
     *
     * @param theme Theme name (e.g., "dark", "light")
     * @return Count of users with that theme
     */
    long countByTheme(String theme);

    /**
     * Find all users with a specific language.
     * Useful for internationalization analytics.
     *
     * @param language Language code (e.g., "en-US")
     * @return Count of users with that language
     */
    long countByLanguage(String language);
}
