package com.example.demo.repository.cassandra;

import com.example.demo.model.entity.ProductCatalog;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Cassandra repository for ProductCatalog entity.
 *
 * Key considerations for Cassandra queries:
 * 1. Always include the partition key in WHERE clause for best performance
 * 2. Can filter on clustering columns in the order they're defined
 * 3. Avoid full table scans (queries without partition key)
 */
@Repository
public interface ProductCatalogRepository extends CassandraRepository<ProductCatalog, UUID> {

    /**
     * Find all products by category.
     * This is efficient because category is the partition key.
     */
    List<ProductCatalog> findByCategory(String category);

    /**
     * Find products by category and created after a certain date.
     * Efficient because it uses partition key + clustering column.
     */
    List<ProductCatalog> findByCategoryAndCreatedAtAfter(String category, LocalDateTime createdAt);

    /**
     * Find products by category and created before a certain date.
     */
    List<ProductCatalog> findByCategoryAndCreatedAtBefore(String category, LocalDateTime createdAt);

    /**
     * Find products by category within a date range.
     */
    List<ProductCatalog> findByCategoryAndCreatedAtBetween(String category,
                                                           LocalDateTime startDate,
                                                           LocalDateTime endDate);

    /**
     * Find active products by category.
     * Note: Filtering on non-key columns requires ALLOW FILTERING in CQL,
     * which can be slow on large datasets.
     */
    @Query("SELECT * FROM product_catalog WHERE category = ?0 AND is_active = true ALLOW FILTERING")
    List<ProductCatalog> findActiveByCategoryWithFiltering(String category);

    /**
     * Find products by category and manufacturer.
     */
    @Query("SELECT * FROM product_catalog WHERE category = ?0 AND manufacturer = ?1 ALLOW FILTERING")
    List<ProductCatalog> findByCategoryAndManufacturerWithFiltering(String category, String manufacturer);

    /**
     * Count products in a category.
     */
    long countByCategory(String category);

    /**
     * Delete products by category (be careful - deletes entire partition).
     */
    void deleteByCategory(String category);
}
