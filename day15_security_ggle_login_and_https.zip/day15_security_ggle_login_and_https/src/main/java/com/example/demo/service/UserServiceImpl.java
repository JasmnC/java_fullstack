package com.example.demo.service;

import com.example.demo.model.User;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Override
    public User createUser(User user) {
        throw new UnsupportedOperationException("Not implemented - use userServiceJdbc, userServiceHibernate, or userServiceJpa");
    }

    @Override
    public Optional<User> getUserById(Long id) {
        throw new UnsupportedOperationException("Not implemented - use userServiceJdbc, userServiceHibernate, or userServiceJpa");
    }

    @Override
    public List<User> getAllUsers() {
        throw new UnsupportedOperationException("Not implemented - use userServiceJdbc, userServiceHibernate, or userServiceJpa");
    }

    @Override
    public User updateUser(User user) {
        throw new UnsupportedOperationException("Not implemented - use userServiceJdbc, userServiceHibernate, or userServiceJpa");
    }

    @Override
    public void deleteUser(Long id) {
        throw new UnsupportedOperationException("Not implemented - use userServiceJdbc, userServiceHibernate, or userServiceJpa");
    }

    @Override
    public boolean userExists(Long id) {
        throw new UnsupportedOperationException("Not implemented - use userServiceJdbc, userServiceHibernate, or userServiceJpa");
    }
}



