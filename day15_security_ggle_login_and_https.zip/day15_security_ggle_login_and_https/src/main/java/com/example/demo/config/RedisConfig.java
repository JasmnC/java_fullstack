package com.example.demo.config;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsontype.BasicPolymorphicTypeValidator;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * Redis Configuration for Caching
 *
 * This configuration sets up Redis as the caching provider for the application.
 * It uses Jackson2 JSON serialization for human-readable cache values and
 * configures different TTL (Time To Live) values for different cache types.
 */

@Profile("with-nosql")
@Configuration
public class RedisConfig {

    /**
     * Configure Redis Cache Manager with custom TTL settings for different caches.
     *
     * Cache TTL Strategy:
     * - "users" (individual user by ID): 30 minutes
     * - "allUsers" (list of all users): 10 minutes (shorter as it changes frequently)
     * - "userExists" (existence check): 15 minutes
     *
     * @param connectionFactory Redis connection factory (auto-configured by Spring Boot)
     * @return Configured cache manager
     */
    @Bean
    public CacheManager cacheManager(RedisConnectionFactory connectionFactory) {
        // Create ObjectMapper with type information for polymorphic deserialization
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.activateDefaultTyping(
                BasicPolymorphicTypeValidator.builder()
                        .allowIfBaseType(Object.class)
                        .build(),
                ObjectMapper.DefaultTyping.NON_FINAL,
                JsonTypeInfo.As.PROPERTY
        );

        // Create JSON serializer for Redis values
        GenericJackson2JsonRedisSerializer jsonSerializer =
                new GenericJackson2JsonRedisSerializer(objectMapper);

        // Default cache configuration (30 minutes TTL)
        RedisCacheConfiguration defaultConfig = RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofMinutes(30))
                .serializeKeysWith(
                        RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer())
                )
                .serializeValuesWith(
                        RedisSerializationContext.SerializationPair.fromSerializer(jsonSerializer)
                )
                .disableCachingNullValues(); // Don't cache null values

        // Custom TTL configurations for specific caches
        Map<String, RedisCacheConfiguration> cacheConfigurations = new HashMap<>();

        // ==================== PostgreSQL/JPA CACHES ====================

        // Individual user cache - 30 minutes
        cacheConfigurations.put("users",
                defaultConfig.entryTtl(Duration.ofMinutes(30)));

        // All users list cache - 10 minutes (changes more frequently)
        cacheConfigurations.put("allUsers",
                defaultConfig.entryTtl(Duration.ofMinutes(10)));

        // User existence check cache - 15 minutes
        cacheConfigurations.put("userExists",
                defaultConfig.entryTtl(Duration.ofMinutes(15)));

        // ==================== MONGODB CACHES ====================

        // User preferences cache - 60 minutes (read-heavy, infrequent updates)
        cacheConfigurations.put("userPreferences",
                defaultConfig.entryTtl(Duration.ofMinutes(60)));

        // Recent activity logs cache - 5 minutes (high write volume, short TTL)
        cacheConfigurations.put("recentActivity",
                defaultConfig.entryTtl(Duration.ofMinutes(5)));

        // Audit summary cache - 30 minutes (immutable data, safe to cache)
        cacheConfigurations.put("auditSummary",
                defaultConfig.entryTtl(Duration.ofMinutes(30)));

        // Activity count cache - 15 minutes
        cacheConfigurations.put("activityCount",
                defaultConfig.entryTtl(Duration.ofMinutes(15)));

        // Build and return cache manager
        return RedisCacheManager.builder(connectionFactory)
                .cacheDefaults(defaultConfig)
                .withInitialCacheConfigurations(cacheConfigurations)
                .transactionAware() // Make cache operations transactional
                .build();
    }

    /**
     * Configure RedisTemplate for manual Redis operations (if needed).
     * This is optional but useful for custom cache operations outside of @Cacheable.
     *
     * @param connectionFactory Redis connection factory
     * @return Configured RedisTemplate
     */
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(connectionFactory);

        // Use String serializer for keys
        StringRedisSerializer stringSerializer = new StringRedisSerializer();
        template.setKeySerializer(stringSerializer);
        template.setHashKeySerializer(stringSerializer);

        // Use JSON serializer for values
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.activateDefaultTyping(
                BasicPolymorphicTypeValidator.builder()
                        .allowIfBaseType(Object.class)
                        .build(),
                ObjectMapper.DefaultTyping.NON_FINAL,
                JsonTypeInfo.As.PROPERTY
        );

        GenericJackson2JsonRedisSerializer jsonSerializer =
                new GenericJackson2JsonRedisSerializer(objectMapper);
        template.setValueSerializer(jsonSerializer);
        template.setHashValueSerializer(jsonSerializer);

        template.afterPropertiesSet();
        return template;
    }
}
