package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.UserServiceJpa;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Cache Testing Controller
 *
 * Provides endpoints to test and monitor Redis cache behavior.
 * Use these endpoints to verify cache hits/misses, view cache statistics,
 * and manually manage cache entries.
 */
@RestController
@RequestMapping("/v1/api/cache")
public class CacheTestController {

    private static final Logger logger = LoggerFactory.getLogger(CacheTestController.class);

    private final UserServiceJpa userServiceJpa;
    private final CacheManager cacheManager;

    public CacheTestController(UserServiceJpa userServiceJpa, CacheManager cacheManager) {
        this.userServiceJpa = userServiceJpa;
        this.cacheManager = cacheManager;
    }

    // ==================== CACHE TESTING ENDPOINTS ====================

    /**
     * Test cache behavior by fetching the same user multiple times.
     * First call should be a cache miss (database hit), subsequent calls should be cache hits.
     *
     * Endpoint: GET /v1/api/cache/test-user/{userId}
     *
     * @param userId User ID to test
     * @return Response with cache hit/miss information
     */
    @GetMapping("/test-user/{userId}")
    public ResponseEntity<Map<String, Object>> testUserCache(@PathVariable Long userId) {
        logger.info("Testing cache for user ID: {}", userId);

        Map<String, Object> response = new HashMap<>();
        long startTime, endTime;

        // First fetch - should be a cache miss (database hit)
        startTime = System.currentTimeMillis();
        Optional<User> user1 = userServiceJpa.getUserById(userId);
        endTime = System.currentTimeMillis();
        long firstFetchTime = endTime - startTime;

        // Wait a bit to ensure clear separation
        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Second fetch - should be a cache hit
        startTime = System.currentTimeMillis();
        Optional<User> user2 = userServiceJpa.getUserById(userId);
        endTime = System.currentTimeMillis();
        long secondFetchTime = endTime - startTime;

        // Third fetch - should also be a cache hit
        startTime = System.currentTimeMillis();
        Optional<User> user3 = userServiceJpa.getUserById(userId);
        endTime = System.currentTimeMillis();
        long thirdFetchTime = endTime - startTime;

        response.put("userId", userId);
        response.put("userFound", user1.isPresent());
        response.put("firstFetchTimeMs", firstFetchTime);
        response.put("secondFetchTimeMs", secondFetchTime);
        response.put("thirdFetchTimeMs", thirdFetchTime);
        response.put("speedupFactor", firstFetchTime > 0 ? (double) firstFetchTime / secondFetchTime : 0);
        response.put("explanation", "First fetch is slower (cache miss). Subsequent fetches are faster (cache hits).");
        response.put("note", "Check logs for 'Cache MISS' message on first fetch only.");

        return ResponseEntity.ok(response);
    }

    /**
     * Test cache eviction by updating a user.
     * After update, the cache should be invalidated.
     *
     * Endpoint: POST /v1/api/cache/test-eviction/{userId}
     *
     * @param userId User ID to test
     * @return Response with eviction test results
     */
    @PostMapping("/test-eviction/{userId}")
    public ResponseEntity<Map<String, Object>> testCacheEviction(@PathVariable Long userId) {
        logger.info("Testing cache eviction for user ID: {}", userId);

        Map<String, Object> response = new HashMap<>();

        // 1. Fetch user to populate cache
        Optional<User> user1 = userServiceJpa.getUserById(userId);
        if (user1.isEmpty()) {
            response.put("error", "User not found");
            return ResponseEntity.notFound().build();
        }

        response.put("step1", "User fetched and cached");
        response.put("beforeUpdate", user1.get());

        // 2. Update the user (should evict cache)
        User userToUpdate = user1.get();
        String originalFirstName = userToUpdate.getFirstName();
        userToUpdate.setFirstName(originalFirstName + "-Updated");

        User updatedUser = userServiceJpa.updateUser(userToUpdate);
        response.put("step2", "User updated - cache evicted");
        response.put("afterUpdate", updatedUser);

        // 3. Fetch again (should be a cache miss, then repopulate cache)
        Optional<User> user3 = userServiceJpa.getUserById(userId);
        response.put("step3", "User refetched - new data should be in cache");
        response.put("refetched", user3.get());

        response.put("explanation", "Cache was evicted on update, so refetch loads new data from database.");
        response.put("note", "Check logs for two 'Cache MISS' messages: initial fetch and after-update fetch.");

        return ResponseEntity.ok(response);
    }

    // ==================== CACHE STATISTICS & MANAGEMENT ====================

    /**
     * Get cache statistics and information.
     *
     * Endpoint: GET /v1/api/cache/stats
     *
     * @return Cache statistics
     */
    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getCacheStats() {
        Map<String, Object> stats = new HashMap<>();

        // Get all cache names
        List<String> cacheNames = List.of("users", "allUsers", "userExists");

        Map<String, Object> cacheInfo = new HashMap<>();
        for (String cacheName : cacheNames) {
            Cache cache = cacheManager.getCache(cacheName);
            if (cache != null) {
                Map<String, Object> info = new HashMap<>();
                info.put("name", cache.getName());
                info.put("nativeCache", cache.getNativeCache().getClass().getSimpleName());
                info.put("status", "Active");
                cacheInfo.put(cacheName, info);
            }
        }

        stats.put("cacheManager", cacheManager.getClass().getSimpleName());
        stats.put("caches", cacheInfo);
        stats.put("totalCaches", cacheInfo.size());

        return ResponseEntity.ok(stats);
    }

    /**
     * Manually evict a specific user from cache.
     *
     * Endpoint: DELETE /v1/api/cache/evict/user/{userId}
     *
     * @param userId User ID to evict from cache
     * @return Eviction result
     */
    @DeleteMapping("/evict/user/{userId}")
    public ResponseEntity<Map<String, String>> evictUserCache(@PathVariable Long userId) {
        logger.info("Manually evicting user cache for ID: {}", userId);

        Cache usersCache = cacheManager.getCache("users");
        Cache userExistsCache = cacheManager.getCache("userExists");

        if (usersCache != null) {
            usersCache.evict(userId);
        }
        if (userExistsCache != null) {
            userExistsCache.evict(userId);
        }

        Map<String, String> response = new HashMap<>();
        response.put("message", "User cache evicted for ID: " + userId);
        response.put("evictedCaches", "users, userExists");

        return ResponseEntity.ok(response);
    }

    /**
     * Manually evict all users list from cache.
     *
     * Endpoint: DELETE /v1/api/cache/evict/all-users
     *
     * @return Eviction result
     */
    @DeleteMapping("/evict/all-users")
    public ResponseEntity<Map<String, String>> evictAllUsersCache() {
        logger.info("Manually evicting allUsers cache");

        Cache allUsersCache = cacheManager.getCache("allUsers");
        if (allUsersCache != null) {
            allUsersCache.clear();
        }

        Map<String, String> response = new HashMap<>();
        response.put("message", "All users cache cleared");
        response.put("evictedCache", "allUsers");

        return ResponseEntity.ok(response);
    }

    /**
     * Clear all caches.
     *
     * Endpoint: DELETE /v1/api/cache/clear-all
     *
     * @return Clear result
     */
    @DeleteMapping("/clear-all")
    public ResponseEntity<Map<String, Object>> clearAllCaches() {
        logger.info("Clearing all caches");

        List<String> cacheNames = List.of("users", "allUsers", "userExists");
        int clearedCount = 0;

        for (String cacheName : cacheNames) {
            Cache cache = cacheManager.getCache(cacheName);
            if (cache != null) {
                cache.clear();
                clearedCount++;
            }
        }

        Map<String, Object> response = new HashMap<>();
        response.put("message", "All caches cleared");
        response.put("clearedCaches", cacheNames);
        response.put("totalCleared", clearedCount);

        return ResponseEntity.ok(response);
    }

    // ==================== INFORMATION ENDPOINT ====================

    /**
     * Get information about cache testing endpoints.
     *
     * Endpoint: GET /v1/api/cache/info
     *
     * @return Information about available endpoints
     */
    @GetMapping("/info")
    public ResponseEntity<Map<String, Object>> getCacheInfo() {
        Map<String, Object> info = new HashMap<>();
        info.put("title", "Redis Cache Testing Endpoints");
        info.put("description", "Endpoints to test and monitor Redis caching behavior");

        Map<String, String> endpoints = new HashMap<>();
        endpoints.put("GET /cache/test-user/{id}", "Test cache hit/miss for user by ID (fetches 3 times)");
        endpoints.put("POST /cache/test-eviction/{id}", "Test cache eviction on user update");
        endpoints.put("GET /cache/stats", "View cache statistics and configuration");
        endpoints.put("DELETE /cache/evict/user/{id}", "Manually evict user from cache");
        endpoints.put("DELETE /cache/evict/all-users", "Manually evict all users list cache");
        endpoints.put("DELETE /cache/clear-all", "Clear all caches");
        endpoints.put("GET /cache/info", "Get this information");

        Map<String, String> cacheConfig = new HashMap<>();
        cacheConfig.put("users", "Individual user by ID - TTL: 30 minutes");
        cacheConfig.put("allUsers", "List of all users - TTL: 10 minutes");
        cacheConfig.put("userExists", "User existence check - TTL: 15 minutes");

        info.put("endpoints", endpoints);
        info.put("cacheTypes", cacheConfig);
        info.put("note", "Watch the logs to see 'Cache MISS' messages when data is fetched from the database");

        return ResponseEntity.ok(info);
    }
}
