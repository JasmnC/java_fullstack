package com.example.demo.repository.mongo;

import com.example.demo.model.document.UserActivityLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

/**
 * UserActivityLogRepository - Spring Data MongoDB Repository
 *
 * Provides database operations for UserActivityLog documents.
 * Uses Spring Data MongoDB's automatic query generation and custom queries.
 *
 * Query Methods:
 * - Spring Data generates implementations automatically from method names
 * - Custom queries use @Query annotation with MongoDB query syntax
 * - Pagination and sorting supported via Pageable parameter
 */
@Repository
public interface UserActivityLogRepository extends MongoRepository<UserActivityLog, String> {

    /**
     * Find all activity logs for a specific user.
     * Ordered by timestamp descending (most recent first).
     *
     * @param userId User ID from PostgreSQL
     * @param pageable Pagination and sorting parameters
     * @return Page of activity logs
     */
    Page<UserActivityLog> findByUserIdOrderByTimestampDesc(Long userId, Pageable pageable);

    /**
     * Find activity logs for a user within a time range.
     *
     * @param userId User ID
     * @param startTime Start of time range
     * @param endTime End of time range
     * @return List of activity logs
     */
    List<UserActivityLog> findByUserIdAndTimestampBetween(Long userId, Instant startTime, Instant endTime);

    /**
     * Find activity logs by type for a user.
     * Examples: LOGIN, API_CALL, UPDATE_PROFILE
     *
     * @param userId User ID
     * @param activityType Type of activity
     * @param pageable Pagination parameters
     * @return Page of activity logs
     */
    Page<UserActivityLog> findByUserIdAndActivityType(Long userId, String activityType, Pageable pageable);

    /**
     * Find activity logs for a specific endpoint.
     * Useful for API usage analytics.
     *
     * @param endpoint API endpoint
     * @param pageable Pagination parameters
     * @return Page of activity logs
     */
    Page<UserActivityLog> findByEndpoint(String endpoint, Pageable pageable);

    /**
     * Count activity logs for a user.
     *
     * @param userId User ID
     * @return Count of activity logs
     */
    long countByUserId(Long userId);

    /**
     * Count activity logs by type within a time range.
     * Custom query for analytics.
     *
     * @param activityType Type of activity
     * @param startTime Start of time range
     * @param endTime End of time range
     * @return Count of matching logs
     */
    @Query(value = "{ 'activityType': ?0, 'timestamp': { $gte: ?1, $lte: ?2 } }", count = true)
    long countByActivityTypeAndTimeRange(String activityType, Instant startTime, Instant endTime);

    /**
     * Find recent activity logs for a user (last N records).
     *
     * @param userId User ID
     * @param pageable Pagination (limit to N records)
     * @return List of recent activity logs
     */
    List<UserActivityLog> findTop10ByUserIdOrderByTimestampDesc(Long userId);

    /**
     * Delete old activity logs (data retention policy).
     * Example: Delete logs older than 90 days.
     *
     * @param cutoffDate Timestamp before which to delete
     * @return Number of deleted records
     */
    long deleteByTimestampBefore(Instant cutoffDate);

    /**
     * Find activity logs with specific status code.
     * Useful for error analysis.
     *
     * @param statusCode HTTP status code
     * @param pageable Pagination parameters
     * @return Page of activity logs
     */
    Page<UserActivityLog> findByStatusCode(Integer statusCode, Pageable pageable);

    /**
     * Find slow requests (duration above threshold).
     * Performance monitoring query.
     *
     * @param minDuration Minimum duration in milliseconds
     * @param pageable Pagination parameters
     * @return Page of slow requests
     */
    @Query("{ 'requestDurationMs': { $gte: ?0 } }")
    Page<UserActivityLog> findSlowRequests(Long minDuration, Pageable pageable);
}
