package com.example.bank.nosql.mongodb;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "transaction_logs")
public class TransactionLog {
    @Id
    private String id;
    private String type;
    private double amount;

    public TransactionLog() {}
    public TransactionLog(String type, double amount) {
        this.type = type;
        this.amount = amount;
    }

    // getters/setters omitted for brevity
}
