package com.example.bank.service.impl;

import com.example.bank.domain.Account;
import com.example.bank.nosql.mongodb.TransactionDoc;
import com.example.bank.nosql.mongodb.TransactionRepo;
import com.example.bank.repo.AccountRepo;
import com.example.bank.service.AccountService;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@EnableCaching
@Service
public class AccountServiceCoordinator implements AccountService {

    private final AccountRepo accountRepo;
    private final TransactionRepo transactionRepo;

    public AccountServiceCoordinator(AccountRepo accountRepo,
                                     TransactionRepo transactionRepo) {
        this.accountRepo = accountRepo;
        this.transactionRepo = transactionRepo;
    }

    @Override
    public Account create(Account account) {
        // 1 Save to PostgreSQL
        Account saved = accountRepo.save(account);

        // 2 Log creation to MongoDB
        transactionRepo.save(TransactionDoc.builder()
                .accountId(saved.getId())
                .type("CREATE")
                .amount(saved.getBalance())
                .timestamp(Instant.now())
                .build());
        System.out.println(">>> Attempting MongoDB save via TransactionRepo...");

        return saved;
    }

    @Override
    @Cacheable(value = "accounts", key = "#id") // Cache in Redis
    public Account get(Long id) {
        System.out.println("Fetching from database (not cache)...");
        return accountRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Account not found"));
    }

    @Override
    public List<Account> list() {
        return accountRepo.findAll();
    }

    @Override
    public Account update(Long id, Account updated) {
        Account existing = accountRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Account not found"));

        existing.setOwner(updated.getOwner());
        existing.setBalance(updated.getBalance());
        Account saved = accountRepo.save(existing);

        // Log update to Mongo
        transactionRepo.save(TransactionDoc.builder()
                .accountId(saved.getId())
                .type("UPDATE")
                .amount(saved.getBalance())
                .timestamp(Instant.now())
                .build());

        return saved;
    }

    @Override
    public void delete(Long id) {
        accountRepo.deleteById(id);

        // Log deletion to Mongo
        transactionRepo.save(TransactionDoc.builder()
                .accountId(id)
                .type("DELETE")
                .amount(0.0)
                .timestamp(Instant.now())
                .build());
    }
}
