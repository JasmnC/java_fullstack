package com.example.bank.nosql.mongodb;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface TransactionLogRepo extends MongoRepository<TransactionLog, String> {}
