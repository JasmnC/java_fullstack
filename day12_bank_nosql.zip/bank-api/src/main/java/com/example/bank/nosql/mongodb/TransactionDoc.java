package com.example.bank.nosql.mongodb;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "transaction_docs")
public class TransactionDoc {
    @Id
    private String id;
    private Long accountId;
    private String type;
    private Double amount;
    private Instant timestamp;
}
