package com.example.bank.service;

import com.example.bank.domain.Account;
import java.util.List;

public interface AccountService {
    Account create(Account account);
    Account get(Long id);
    List<Account> list();
    Account update(Long id, Account account);
    void delete(Long id);
}
