package com.example.bank.nosql.cassandra;

import lombok.*;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;
import java.time.Instant;

@Table("account_events")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountEvent {
    @PrimaryKey
    private String id;
    private Long accountId;
    private String action;       // e.g., "Account Created"
    private Instant timestamp;
}
