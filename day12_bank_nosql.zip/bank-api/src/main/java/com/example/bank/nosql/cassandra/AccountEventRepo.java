package com.example.bank.nosql.cassandra;

import org.springframework.data.cassandra.repository.CassandraRepository;

//@Repository
//public interface AccountEventRepo extends CassandraRepository<AccountEvent, String> {}
