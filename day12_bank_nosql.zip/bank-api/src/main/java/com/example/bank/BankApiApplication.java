package com.example.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication(
        excludeName = {
                "org.springframework.boot.autoconfigure.cassandra.CassandraAutoConfiguration",
                "org.springframework.boot.autoconfigure.data.cassandra.CassandraDataAutoConfiguration",
                "org.springframework.boot.autoconfigure.cassandra.CassandraReactiveRepositoriesAutoConfiguration"
        }
)
@EnableMongoRepositories(basePackages = "com.example.bank.nosql.mongodb")
public class BankApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(BankApiApplication.class, args);
    }
}
