package com.example.bank.nosql.redis;

import lombok.*;
import org.springframework.data.redis.core.RedisHash;

import java.io.Serializable;

@RedisHash("accounts")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CachedAccount implements Serializable {
    private Long id;
    private String owner;
    private Double balance;
}
