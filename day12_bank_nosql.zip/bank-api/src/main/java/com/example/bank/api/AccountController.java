package com.example.bank.api;

import com.example.bank.domain.Account;
import com.example.bank.service.AccountService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {
    private final AccountService service;
    public AccountController(AccountService service) { this.service = service; }

    @PostMapping
    public ResponseEntity<Account> create(@RequestBody Account a) {
        var saved = service.create(a);
        return ResponseEntity.created(URI.create("/api/accounts/" + saved.getId())).body(saved);
    }

    @GetMapping("/{id}")
    public Account get(@PathVariable Long id) { return service.get(id); }

    @GetMapping
    public List<Account> list() { return service.list(); }

    @PutMapping("/{id}")
    public Account update(@PathVariable Long id, @RequestBody Account a) {
        return service.update(id, a);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
