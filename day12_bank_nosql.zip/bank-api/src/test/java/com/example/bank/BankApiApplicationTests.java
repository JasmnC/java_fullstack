package com.example.bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
