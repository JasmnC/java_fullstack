package com.example.bankapi.api;

import com.example.bankapi.service.AccountService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {
    private final AccountService service;
    public AccountController(AccountService service) { this.service = service; }

    @PostMapping
    public ResponseEntity<AccountDto> create(@Valid @RequestBody AccountDto dto) {
        var saved = service.create(dto);
        return ResponseEntity.created(URI.create("/api/accounts/" + saved.id())).body(saved);
    }

    @GetMapping("/{id}")
    public AccountDto get(@PathVariable Long id) { return service.get(id); }

    @GetMapping
    public List<AccountDto> list() { return service.list(); }

    @PutMapping("/{id}")
    public AccountDto update(@PathVariable Long id, @Valid @RequestBody AccountDto dto) {
        return service.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
