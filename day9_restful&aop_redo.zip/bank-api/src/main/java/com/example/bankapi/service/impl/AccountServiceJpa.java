package com.example.bankapi.service.impl;

import com.example.bankapi.api.AccountDto;
import com.example.bankapi.dao.jpa.AccountRepository;
import com.example.bankapi.domain.Account;
import com.example.bankapi.service.AccountService;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@Profile("jpa")   // activates only when profile is 'jpa'
public class AccountServiceJpa implements AccountService {

    private final AccountRepository repo;

    public AccountServiceJpa(AccountRepository repo) {
        this.repo = repo;
    }

    private static AccountDto map(Account a) {
        return new AccountDto(a.getId(), a.getOwner(), a.getBalance());
    }

    private static Account map(AccountDto d) {
        return Account.builder()
                .id(d.id())
                .owner(d.owner())
                .balance(d.balance())
                .build();
    }

    @Override
    public AccountDto create(AccountDto dto) {
        return map(repo.save(map(dto)));
    }

    @Override
    public AccountDto get(Long id) {
        return repo.findById(id)
                .map(AccountServiceJpa::map)
                .orElseThrow(() -> new IllegalArgumentException("Account not found"));
    }

    @Override
    public List<AccountDto> list() {
        return repo.findAll().stream().map(AccountServiceJpa::map).toList();
    }

    @Override
    public AccountDto update(Long id, AccountDto dto) {
        var existing = repo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Account not found"));
        existing.setOwner(dto.owner());
        existing.setBalance(dto.balance());
        return map(repo.save(existing));
    }

    @Override
    public void delete(Long id) {
        repo.deleteById(id);
    }
}
