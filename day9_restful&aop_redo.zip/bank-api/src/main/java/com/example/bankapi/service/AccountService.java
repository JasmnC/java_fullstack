package com.example.bankapi.service;

import com.example.bankapi.api.AccountDto;
import java.util.List;

public interface AccountService {
    AccountDto create(AccountDto dto);
    AccountDto get(Long id);
    List<AccountDto> list();
    AccountDto update(Long id, AccountDto dto);
    void delete(Long id);
}