package com.example.bankapi.api;
import jakarta.validation.constraints.*;

public record AccountDto(Long id, @NotBlank String owner, @PositiveOrZero Double balance) {}
