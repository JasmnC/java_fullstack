package com.example.transactiondemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactiondemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
