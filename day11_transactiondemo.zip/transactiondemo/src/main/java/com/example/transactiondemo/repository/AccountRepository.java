package com.example.transactiondemo.repository;

import com.example.transactiondemo.entity.Account;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.Optional;


public interface AccountRepository extends JpaRepository<Account, Long> {
    // Pessimistic Lock Example
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select a from Account a where a.id = :id")
    Account findByIdForUpdate(@Param("id") Long id);

}
