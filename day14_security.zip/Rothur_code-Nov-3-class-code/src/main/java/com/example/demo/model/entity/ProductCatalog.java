package com.example.demo.model.entity;

import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

/**
 * Cassandra entity representing a product in the catalog.
 * Cassandra is excellent for:
 * - High write throughput
 * - Time-series data
 * - Large-scale catalogs
 * - Multi-datacenter replication
 */
@Table("product_catalog")
public class ProductCatalog {

    /**
     * Partition key - determines which node stores this data.
     * Using category as partition key allows efficient queries by category.
     */
    @PrimaryKeyColumn(name = "category", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String category;

    /**
     * Clustering key - determines order within a partition.
     * Data is sorted by created_at in descending order (newest first).
     */
    @PrimaryKeyColumn(name = "created_at", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private LocalDateTime createdAt;

    /**
     * Second clustering key for uniqueness.
     */
    @PrimaryKeyColumn(name = "product_id", ordinal = 2, type = PrimaryKeyType.CLUSTERED)
    private UUID productId;

    @Column("product_name")
    private String productName;

    @Column("description")
    private String description;

    @Column("price")
    private BigDecimal price;

    @Column("stock_quantity")
    private Integer stockQuantity;

    @Column("manufacturer")
    private String manufacturer;

    @Column("tags")
    private Set<String> tags;

    @Column("is_active")
    private Boolean isActive;

    @Column("last_updated")
    private LocalDateTime lastUpdated;

    // Constructors
    public ProductCatalog() {
        this.productId = UUID.randomUUID();
        this.createdAt = LocalDateTime.now();
        this.lastUpdated = LocalDateTime.now();
        this.isActive = true;
    }

    public ProductCatalog(String category, String productName, String description,
                         BigDecimal price, Integer stockQuantity, String manufacturer) {
        this();
        this.category = category;
        this.productName = productName;
        this.description = description;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.manufacturer = manufacturer;
    }

    // Getters and Setters
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public UUID getProductId() {
        return productId;
    }

    public void setProductId(UUID productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(Integer stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public Set<String> getTags() {
        return tags;
    }

    public void setTags(Set<String> tags) {
        this.tags = tags;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDateTime lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    @Override
    public String toString() {
        return "ProductCatalog{" +
                "category='" + category + '\'' +
                ", createdAt=" + createdAt +
                ", productId=" + productId +
                ", productName='" + productName + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                ", stockQuantity=" + stockQuantity +
                ", manufacturer='" + manufacturer + '\'' +
                ", tags=" + tags +
                ", isActive=" + isActive +
                ", lastUpdated=" + lastUpdated +
                '}';
    }
}
