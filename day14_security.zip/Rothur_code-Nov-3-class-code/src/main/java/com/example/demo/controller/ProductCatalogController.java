package com.example.demo.controller;

import com.example.demo.model.entity.ProductCatalog;
import com.example.demo.service.ProductCatalogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * REST Controller for Product Catalog operations with Cassandra.
 *
 * Endpoints demonstrate:
 * - CRUD operations
 * - Efficient queries using partition and clustering keys
 * - Time-based queries (Cassandra excels at time-series data)
 */
@Profile("with-nosql")
@RestController
@RequestMapping("/api/cassandra/products")
public class ProductCatalogController {

    private static final Logger logger = LoggerFactory.getLogger(ProductCatalogController.class);

    private final ProductCatalogService productCatalogService;

    @Autowired
    public ProductCatalogController(ProductCatalogService productCatalogService) {
        this.productCatalogService = productCatalogService;
    }

    /**
     * Health check endpoint.
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("database", "Cassandra");
        response.put("service", "Product Catalog");
        return ResponseEntity.ok(response);
    }

    /**
     * Create a new product.
     * POST /api/cassandra/products
     */
    @PostMapping
    public ResponseEntity<ProductCatalog> createProduct(@RequestBody ProductCatalog product) {
        logger.info("Creating product: {}", product.getProductName());
        ProductCatalog created = productCatalogService.createProduct(product);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    /**
     * Get all products (use with caution on large datasets).
     * GET /api/cassandra/products
     */
    @GetMapping
    public ResponseEntity<List<ProductCatalog>> getAllProducts() {
        logger.info("Fetching all products");
        List<ProductCatalog> products = productCatalogService.getAllProducts();
        return ResponseEntity.ok(products);
    }

    /**
     * Get product by ID.
     * GET /api/cassandra/products/{productId}
     */
    @GetMapping("/{productId}")
    public ResponseEntity<ProductCatalog> getProductById(@PathVariable UUID productId) {
        logger.info("Fetching product by ID: {}", productId);
        return productCatalogService.findProductById(productId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Get products by category (efficient query using partition key).
     * GET /api/cassandra/products/category/{category}
     */
    @GetMapping("/category/{category}")
    public ResponseEntity<List<ProductCatalog>> getProductsByCategory(@PathVariable String category) {
        logger.info("Fetching products for category: {}", category);
        List<ProductCatalog> products = productCatalogService.getProductsByCategory(category);
        return ResponseEntity.ok(products);
    }

    /**
     * Get recent products by category.
     * GET /api/cassandra/products/category/{category}/recent?days=7
     */
    @GetMapping("/category/{category}/recent")
    public ResponseEntity<List<ProductCatalog>> getRecentProducts(
            @PathVariable String category,
            @RequestParam(defaultValue = "7") int days) {
        logger.info("Fetching products for category: {} from last {} days", category, days);
        List<ProductCatalog> products = productCatalogService.getRecentProductsByCategory(category, days);
        return ResponseEntity.ok(products);
    }

    /**
     * Get products by category within date range.
     * GET /api/cassandra/products/category/{category}/range?startDate=2024-01-01T00:00:00&endDate=2024-12-31T23:59:59
     */
    @GetMapping("/category/{category}/range")
    public ResponseEntity<List<ProductCatalog>> getProductsByDateRange(
            @PathVariable String category,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        logger.info("Fetching products for category: {} between {} and {}", category, startDate, endDate);
        List<ProductCatalog> products = productCatalogService.getProductsByCategoryAndDateRange(category, startDate, endDate);
        return ResponseEntity.ok(products);
    }

    /**
     * Get active products by category.
     * GET /api/cassandra/products/category/{category}/active
     */
    @GetMapping("/category/{category}/active")
    public ResponseEntity<List<ProductCatalog>> getActiveProducts(@PathVariable String category) {
        logger.info("Fetching active products for category: {}", category);
        List<ProductCatalog> products = productCatalogService.getActiveProductsByCategory(category);
        return ResponseEntity.ok(products);
    }

    /**
     * Get products by category and manufacturer.
     * GET /api/cassandra/products/category/{category}/manufacturer/{manufacturer}
     */
    @GetMapping("/category/{category}/manufacturer/{manufacturer}")
    public ResponseEntity<List<ProductCatalog>> getProductsByManufacturer(
            @PathVariable String category,
            @PathVariable String manufacturer) {
        logger.info("Fetching products for category: {} and manufacturer: {}", category, manufacturer);
        List<ProductCatalog> products = productCatalogService.getProductsByCategoryAndManufacturer(category, manufacturer);
        return ResponseEntity.ok(products);
    }

    /**
     * Update a product.
     * PUT /api/cassandra/products/{productId}
     */
    @PutMapping("/{productId}")
    public ResponseEntity<ProductCatalog> updateProduct(
            @PathVariable UUID productId,
            @RequestBody ProductCatalog product) {
        logger.info("Updating product: {}", productId);
        product.setProductId(productId);
        ProductCatalog updated = productCatalogService.updateProduct(product);
        return ResponseEntity.ok(updated);
    }

    /**
     * Delete a product.
     * DELETE /api/cassandra/products/{productId}
     */
    @DeleteMapping("/{productId}")
    public ResponseEntity<Map<String, String>> deleteProduct(@PathVariable UUID productId) {
        logger.info("Deleting product: {}", productId);
        productCatalogService.deleteProduct(productId);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Product deleted successfully");
        response.put("productId", productId.toString());
        return ResponseEntity.ok(response);
    }

    /**
     * Count products in a category.
     * GET /api/cassandra/products/category/{category}/count
     */
    @GetMapping("/category/{category}/count")
    public ResponseEntity<Map<String, Object>> countProducts(@PathVariable String category) {
        logger.info("Counting products in category: {}", category);
        long count = productCatalogService.countProductsInCategory(category);
        Map<String, Object> response = new HashMap<>();
        response.put("category", category);
        response.put("count", count);
        return ResponseEntity.ok(response);
    }

    /**
     * Delete all products in a category (use with caution).
     * DELETE /api/cassandra/products/category/{category}
     */
    @DeleteMapping("/category/{category}")
    public ResponseEntity<Map<String, String>> deleteProductsByCategory(@PathVariable String category) {
        logger.warn("Deleting all products in category: {}", category);
        productCatalogService.deleteProductsByCategory(category);
        Map<String, String> response = new HashMap<>();
        response.put("message", "All products in category deleted successfully");
        response.put("category", category);
        return ResponseEntity.ok(response);
    }
}
