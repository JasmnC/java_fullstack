package com.example.demo.repository.mongo;

import com.example.demo.model.document.AuditTrail;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

/**
 * AuditTrailRepository - Spring Data MongoDB Repository
 *
 * Provides database operations for AuditTrail documents.
 * Audit records are immutable - write-once, read-many pattern.
 *
 * Key Features:
 * - Compound indexes for efficient queries by user, entity, and time
 * - Time-based retention policy support
 * - Compliance and regulatory reporting queries
 */
@Repository
public interface AuditTrailRepository extends MongoRepository<AuditTrail, String> {

    /**
     * Find all audit trails for a specific user.
     * Ordered by timestamp descending (most recent first).
     *
     * @param userId User ID who performed the action
     * @param pageable Pagination parameters
     * @return Page of audit trails
     */
    Page<AuditTrail> findByUserIdOrderByTimestampDesc(Long userId, Pageable pageable);

    /**
     * Find audit trails for a specific entity and ID.
     * Shows complete change history for a single record.
     *
     * @param targetEntity Entity type (e.g., "User")
     * @param targetEntityId Entity ID
     * @param pageable Pagination parameters
     * @return Page of audit trails
     */
    Page<AuditTrail> findByTargetEntityAndTargetEntityIdOrderByTimestampDesc(
            String targetEntity, Long targetEntityId, Pageable pageable);

    /**
     * Find audit trails by operation type.
     * Examples: CREATE, UPDATE, DELETE
     *
     * @param operation Operation type
     * @param pageable Pagination parameters
     * @return Page of audit trails
     */
    Page<AuditTrail> findByOperation(String operation, Pageable pageable);

    /**
     * Find audit trails within a time range.
     * Compliance reporting query.
     *
     * @param startTime Start of time range
     * @param endTime End of time range
     * @param pageable Pagination parameters
     * @return Page of audit trails
     */
    Page<AuditTrail> findByTimestampBetween(Instant startTime, Instant endTime, Pageable pageable);

    /**
     * Find audit trails for a user and entity type.
     * Example: All User entity changes by specific user.
     *
     * @param userId User ID
     * @param targetEntity Entity type
     * @param pageable Pagination parameters
     * @return Page of audit trails
     */
    Page<AuditTrail> findByUserIdAndTargetEntity(Long userId, String targetEntity, Pageable pageable);

    /**
     * Count audit trails by operation type within a time range.
     * Analytics query for reporting.
     *
     * @param operation Operation type
     * @param startTime Start of time range
     * @param endTime End of time range
     * @return Count of matching audit trails
     */
    long countByOperationAndTimestampBetween(String operation, Instant startTime, Instant endTime);

    /**
     * Find audit trails requiring GDPR compliance.
     * Compliance reporting query.
     *
     * @param pageable Pagination parameters
     * @return Page of GDPR-compliant audit trails
     */
    @Query("{ 'complianceFlags.gdprCompliant': true }")
    Page<AuditTrail> findGdprCompliantRecords(Pageable pageable);

    /**
     * Delete old audit trails (data retention policy).
     * Example: Delete audit trails older than 7 years for compliance.
     *
     * @param cutoffDate Timestamp before which to delete
     * @return Number of deleted records
     */
    long deleteByTimestampBefore(Instant cutoffDate);

    /**
     * Find all changes to a specific entity type.
     * Example: All User entity modifications across all users.
     *
     * @param targetEntity Entity type
     * @param pageable Pagination parameters
     * @return Page of audit trails
     */
    Page<AuditTrail> findByTargetEntityOrderByTimestampDesc(String targetEntity, Pageable pageable);

    /**
     * Find recent audit trails (last N records).
     *
     * @param pageable Pagination (limit to N records)
     * @return List of recent audit trails
     */
    List<AuditTrail> findTop20ByOrderByTimestampDesc();

    /**
     * Count total audit trails for a user.
     *
     * @param userId User ID
     * @return Count of audit trails
     */
    long countByUserId(Long userId);

    /**
     * Find audit trails by IP address.
     * Security investigation query.
     *
     * @param ipAddress IP address to search
     * @param pageable Pagination parameters
     * @return Page of audit trails
     */
    Page<AuditTrail> findByIpAddress(String ipAddress, Pageable pageable);
}
