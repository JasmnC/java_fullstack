package com.example.demo.service;

import com.example.demo.model.entity.ProductCatalog;
import com.example.demo.repository.cassandra.ProductCatalogRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Service layer for managing ProductCatalog operations with Cassandra.
 *
 * Best practices for Cassandra:
 * 1. Design queries based on access patterns (not data model)
 * 2. Denormalize data for query efficiency
 * 3. Use batch writes carefully (only for same partition)
 * 4. Monitor partition sizes (avoid hot partitions)
 */
@Profile("with-nosql")
@Service
public class ProductCatalogService {

    private static final Logger logger = LoggerFactory.getLogger(ProductCatalogService.class);

    private final ProductCatalogRepository productCatalogRepository;

    @Autowired
    public ProductCatalogService(ProductCatalogRepository productCatalogRepository) {
        this.productCatalogRepository = productCatalogRepository;
    }

    /**
     * Create a new product in the catalog.
     */
    public ProductCatalog createProduct(ProductCatalog product) {
        logger.info("Creating new product: {} in category: {}", product.getProductName(), product.getCategory());
        product.setCreatedAt(LocalDateTime.now());
        product.setLastUpdated(LocalDateTime.now());
        return productCatalogRepository.save(product);
    }

    /**
     * Get all products in the catalog (use with caution on large datasets).
     */
    public List<ProductCatalog> getAllProducts() {
        logger.info("Fetching all products from catalog");
        return productCatalogRepository.findAll();
    }

    /**
     * Get products by category (efficient - uses partition key).
     */
    public List<ProductCatalog> getProductsByCategory(String category) {
        logger.info("Fetching products for category: {}", category);
        return productCatalogRepository.findByCategory(category);
    }

    /**
     * Get recent products by category.
     */
    public List<ProductCatalog> getRecentProductsByCategory(String category, int daysBack) {
        LocalDateTime sinceDate = LocalDateTime.now().minusDays(daysBack);
        logger.info("Fetching products for category: {} created after: {}", category, sinceDate);
        return productCatalogRepository.findByCategoryAndCreatedAtAfter(category, sinceDate);
    }

    /**
     * Get products by category within a date range.
     */
    public List<ProductCatalog> getProductsByCategoryAndDateRange(String category,
                                                                   LocalDateTime startDate,
                                                                   LocalDateTime endDate) {
        logger.info("Fetching products for category: {} between {} and {}", category, startDate, endDate);
        return productCatalogRepository.findByCategoryAndCreatedAtBetween(category, startDate, endDate);
    }

    /**
     * Get active products by category.
     */
    public List<ProductCatalog> getActiveProductsByCategory(String category) {
        logger.info("Fetching active products for category: {}", category);
        return productCatalogRepository.findActiveByCategoryWithFiltering(category);
    }

    /**
     * Get products by category and manufacturer.
     */
    public List<ProductCatalog> getProductsByCategoryAndManufacturer(String category, String manufacturer) {
        logger.info("Fetching products for category: {} and manufacturer: {}", category, manufacturer);
        return productCatalogRepository.findByCategoryAndManufacturerWithFiltering(category, manufacturer);
    }

    /**
     * Update a product.
     */
    public ProductCatalog updateProduct(ProductCatalog product) {
        logger.info("Updating product: {}", product.getProductId());
        product.setLastUpdated(LocalDateTime.now());
        return productCatalogRepository.save(product);
    }

    /**
     * Delete a product by ID.
     */
    public void deleteProduct(UUID productId) {
        logger.info("Deleting product: {}", productId);
        productCatalogRepository.deleteById(productId);
    }

    /**
     * Delete all products in a category.
     */
    public void deleteProductsByCategory(String category) {
        logger.warn("Deleting all products in category: {}", category);
        productCatalogRepository.deleteByCategory(category);
    }

    /**
     * Count products in a category.
     */
    public long countProductsInCategory(String category) {
        logger.info("Counting products in category: {}", category);
        return productCatalogRepository.countByCategory(category);
    }

    /**
     * Check if a product exists.
     */
    public boolean productExists(UUID productId) {
        return productCatalogRepository.existsById(productId);
    }

    /**
     * Find product by ID.
     */
    public Optional<ProductCatalog> findProductById(UUID productId) {
        logger.info("Finding product by ID: {}", productId);
        return productCatalogRepository.findById(productId);
    }
}
