package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.UserServiceJpa;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

/**
 * Demo controller to demonstrate optimistic and pessimistic locking behavior.
 * These endpoints are for testing and educational purposes.
 */
@RestController
@RequestMapping("/v1/api/demo/locking")
public class UserLockingDemoController {

    private static final Logger logger = LoggerFactory.getLogger(UserLockingDemoController.class);
    private final UserServiceJpa userServiceJpa;

    public UserLockingDemoController(UserServiceJpa userServiceJpa) {
        this.userServiceJpa = userServiceJpa;
    }

    // ==================== OPTIMISTIC LOCKING DEMOS ====================

    /**
     * Demonstrates optimistic locking by simulating concurrent updates.
     * This endpoint will attempt to update the same user twice simultaneously,
     * which will trigger an OptimisticLockException on one of the updates.
     *
     * Endpoint: POST /v1/api/demo/locking/optimistic-conflict/{userId}
     * Body: { "firstName": "NewName", "lastName": "NewLastName", "email": "new@example.com" }
     *
     * @param userId User ID to update
     * @param updateData Updated user data
     * @return Result of the concurrent update test
     */
    @PostMapping("/optimistic-conflict/{userId}")
    public ResponseEntity<Map<String, Object>> simulateOptimisticConflict(
            @PathVariable Long userId,
            @RequestBody User updateData) {

        logger.info("Simulating optimistic lock conflict for user ID: {}", userId);

        // Fetch the user twice to simulate two separate transactions
        User user1 = userServiceJpa.getUserById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));
        User user2 = userServiceJpa.getUserById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

        Map<String, Object> result = new HashMap<>();
        result.put("userId", userId);
        result.put("initialVersion", user1.getVersion());

        try {
            // First update - this should succeed
            user1.setFirstName(updateData.getFirstName() + "-Update1");
            user1.setLastName(updateData.getLastName());
            user1.setEmail(updateData.getEmail());
            User updated1 = userServiceJpa.updateUser(user1);
            result.put("firstUpdateSuccess", true);
            result.put("firstUpdateVersion", updated1.getVersion());

            // Second update with stale version - this should trigger OptimisticLockException
            user2.setFirstName(updateData.getFirstName() + "-Update2");
            user2.setLastName(updateData.getLastName());
            user2.setEmail(updateData.getEmail());

            try {
                User updated2 = userServiceJpa.updateUser(user2);
                result.put("secondUpdateSuccess", true);
                result.put("secondUpdateVersion", updated2.getVersion());
                result.put("message", "Unexpected: Both updates succeeded (this shouldn't happen with optimistic locking)");
            } catch (RuntimeException e) {
                result.put("secondUpdateSuccess", false);
                result.put("secondUpdateError", e.getMessage());
                result.put("message", "Expected behavior: Second update failed due to version conflict (optimistic locking working correctly)");
            }

            return ResponseEntity.ok(result);

        } catch (Exception e) {
            logger.error("Error during optimistic conflict simulation", e);
            result.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(result);
        }
    }

    /**
     * Get user with version information to inspect optimistic locking state.
     *
     * Endpoint: GET /v1/api/demo/locking/user-with-version/{userId}
     *
     * @param userId User ID
     * @return User with version information
     */
    @GetMapping("/user-with-version/{userId}")
    public ResponseEntity<Map<String, Object>> getUserWithVersion(@PathVariable Long userId) {
        User user = userServiceJpa.getUserById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

        Map<String, Object> response = new HashMap<>();
        response.put("id", user.getId());
        response.put("firstName", user.getFirstName());
        response.put("lastName", user.getLastName());
        response.put("email", user.getEmail());
        response.put("version", user.getVersion());
        response.put("message", "Version field is used for optimistic locking. It increments with each update.");

        return ResponseEntity.ok(response);
    }

    // ==================== PESSIMISTIC LOCKING DEMOS ====================

    /**
     * Updates a user using pessimistic write lock.
     * This will lock the row during the transaction, preventing other transactions from accessing it.
     *
     * Endpoint: PUT /v1/api/demo/locking/pessimistic-update/{userId}
     * Body: { "firstName": "NewName", "lastName": "NewLastName", "email": "new@example.com" }
     *
     * @param userId User ID to update
     * @param updatedUser Updated user data
     * @return Updated user
     */
    @PutMapping("/pessimistic-update/{userId}")
    public ResponseEntity<Map<String, Object>> updateWithPessimisticLock(
            @PathVariable Long userId,
            @RequestBody User updatedUser) {

        logger.info("Updating user with pessimistic lock. User ID: {}", userId);

        User updated = userServiceJpa.updateUserWithPessimisticLock(userId, updatedUser);

        Map<String, Object> response = new HashMap<>();
        response.put("user", updated);
        response.put("message", "User updated successfully using pessimistic write lock");
        response.put("lockType", "PESSIMISTIC_WRITE");

        return ResponseEntity.ok(response);
    }

    /**
     * Demonstrates pessimistic read lock by fetching a user with read lock.
     *
     * Endpoint: GET /v1/api/demo/locking/pessimistic-read/{userId}
     *
     * @param userId User ID
     * @return User data with lock information
     */
    @GetMapping("/pessimistic-read/{userId}")
    public ResponseEntity<Map<String, Object>> getUserWithReadLock(@PathVariable Long userId) {
        logger.info("Fetching user with pessimistic read lock. User ID: {}", userId);

        User user = userServiceJpa.getUserByIdWithReadLock(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

        Map<String, Object> response = new HashMap<>();
        response.put("user", user);
        response.put("message", "User fetched with pessimistic read lock (allows concurrent reads, blocks writes)");
        response.put("lockType", "PESSIMISTIC_READ");

        return ResponseEntity.ok(response);
    }

    /**
     * Demonstrates pessimistic write lock by fetching a user with write lock.
     *
     * Endpoint: GET /v1/api/demo/locking/pessimistic-write/{userId}
     *
     * @param userId User ID
     * @return User data with lock information
     */
    @GetMapping("/pessimistic-write/{userId}")
    public ResponseEntity<Map<String, Object>> getUserWithWriteLock(@PathVariable Long userId) {
        logger.info("Fetching user with pessimistic write lock. User ID: {}", userId);

        User user = userServiceJpa.getUserByIdWithWriteLock(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

        Map<String, Object> response = new HashMap<>();
        response.put("user", user);
        response.put("message", "User fetched with pessimistic write lock (blocks all other access)");
        response.put("lockType", "PESSIMISTIC_WRITE");

        return ResponseEntity.ok(response);
    }

    /**
     * Finds users by email with pessimistic lock.
     *
     * Endpoint: GET /v1/api/demo/locking/by-email-locked?email={email}
     *
     * @param email User email to search for
     * @return User with lock information
     */
    @GetMapping("/by-email-locked")
    public ResponseEntity<Map<String, Object>> getUserByEmailWithLock(@RequestParam String email) {
        logger.info("Fetching user by email with pessimistic lock. Email: {}", email);

        User user = userServiceJpa.getUserByEmailWithLock(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));

        Map<String, Object> response = new HashMap<>();
        response.put("user", user);
        response.put("message", "User fetched by email with pessimistic write lock");
        response.put("lockType", "PESSIMISTIC_WRITE");

        return ResponseEntity.ok(response);
    }

    /**
     * Finds users by first name with pessimistic lock.
     *
     * Endpoint: GET /v1/api/demo/locking/by-firstname-locked?firstName={firstName}
     *
     * @param firstName First name to search for
     * @return List of users with lock information
     */
    @GetMapping("/by-firstname-locked")
    public ResponseEntity<Map<String, Object>> getUsersByFirstNameWithLock(@RequestParam String firstName) {
        logger.info("Fetching users by first name with pessimistic lock. First name: {}", firstName);

        List<User> users = userServiceJpa.getUsersByFirstNameWithLock(firstName);

        Map<String, Object> response = new HashMap<>();
        response.put("users", users);
        response.put("count", users.size());
        response.put("message", "Users fetched by first name with pessimistic write lock");
        response.put("lockType", "PESSIMISTIC_WRITE");

        return ResponseEntity.ok(response);
    }

    // ==================== CONCURRENT UPDATE DEMOS ====================

    /**
     * Simulates multiple concurrent updates to test locking behavior.
     * Spawns multiple threads that attempt to update the same user simultaneously.
     *
     * Endpoint: POST /v1/api/demo/locking/concurrent-updates/{userId}
     * Query params: threads (default 5), lockType (OPTIMISTIC or PESSIMISTIC)
     *
     * @param userId User ID to update
     * @param threads Number of concurrent threads (default 5)
     * @param lockType Type of locking to use (OPTIMISTIC or PESSIMISTIC)
     * @return Results of concurrent updates
     */
    @PostMapping("/concurrent-updates/{userId}")
    public ResponseEntity<Map<String, Object>> simulateConcurrentUpdates(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "5") int threads,
            @RequestParam(defaultValue = "OPTIMISTIC") String lockType) {

        logger.info("Simulating {} concurrent updates with {} locking for user ID: {}",
                threads, lockType, userId);

        ExecutorService executor = Executors.newFixedThreadPool(threads);
        CountDownLatch latch = new CountDownLatch(threads);
        Map<Integer, Map<String, Object>> results = new ConcurrentHashMap<>();

        for (int i = 0; i < threads; i++) {
            final int threadNum = i;
            executor.submit(() -> {
                try {
                    // Wait for all threads to be ready, then start simultaneously
                    latch.countDown();
                    latch.await();

                    Map<String, Object> threadResult = new HashMap<>();
                    threadResult.put("threadId", threadNum);
                    threadResult.put("startTime", System.currentTimeMillis());

                    try {
                        User user;
                        if ("PESSIMISTIC".equalsIgnoreCase(lockType)) {
                            // Use pessimistic locking
                            User updateData = new User();
                            updateData.setFirstName("Thread-" + threadNum);
                            updateData.setLastName("PessimisticTest");
                            updateData.setEmail("thread" + threadNum + "@test.com");
                            user = userServiceJpa.updateUserWithPessimisticLock(userId, updateData);
                            threadResult.put("lockType", "PESSIMISTIC");
                        } else {
                            // Use optimistic locking
                            user = userServiceJpa.getUserById(userId)
                                    .orElseThrow(() -> new RuntimeException("User not found"));
                            user.setFirstName("Thread-" + threadNum);
                            user.setLastName("OptimisticTest");
                            user.setEmail("thread" + threadNum + "@test.com");
                            user = userServiceJpa.updateUser(user);
                            threadResult.put("lockType", "OPTIMISTIC");
                        }

                        threadResult.put("success", true);
                        threadResult.put("finalVersion", user.getVersion());
                        threadResult.put("finalFirstName", user.getFirstName());

                    } catch (Exception e) {
                        threadResult.put("success", false);
                        threadResult.put("error", e.getMessage());
                        threadResult.put("errorType", e.getClass().getSimpleName());
                    }

                    threadResult.put("endTime", System.currentTimeMillis());
                    threadResult.put("duration",
                            (long) threadResult.get("endTime") - (long) threadResult.get("startTime"));
                    results.put(threadNum, threadResult);

                } catch (InterruptedException e) {
                    logger.error("Thread interrupted", e);
                    Thread.currentThread().interrupt();
                }
            });
        }

        executor.shutdown();
        try {
            executor.awaitTermination(30, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            logger.error("Executor interrupted", e);
            Thread.currentThread().interrupt();
        }

        // Calculate summary statistics
        long successCount = results.values().stream()
                .filter(r -> (boolean) r.get("success"))
                .count();
        long failureCount = threads - successCount;

        Map<String, Object> summary = new HashMap<>();
        summary.put("userId", userId);
        summary.put("lockType", lockType);
        summary.put("totalThreads", threads);
        summary.put("successfulUpdates", successCount);
        summary.put("failedUpdates", failureCount);
        summary.put("threadResults", results);

        if ("OPTIMISTIC".equalsIgnoreCase(lockType)) {
            summary.put("explanation", "With optimistic locking, multiple threads can read the same data, " +
                    "but only one update succeeds. Others fail with version conflicts and retry.");
        } else {
            summary.put("explanation", "With pessimistic locking, threads queue up to acquire the lock. " +
                    "Each thread waits for the previous one to complete, ensuring no conflicts.");
        }

        return ResponseEntity.ok(summary);
    }

    /**
     * Health check endpoint for the locking demo controller.
     *
     * Endpoint: GET /v1/api/demo/locking/info
     *
     * @return Information about available demo endpoints
     */
    @GetMapping("/info")
    public ResponseEntity<Map<String, Object>> getLockingInfo() {
        Map<String, Object> info = new HashMap<>();
        info.put("title", "JPA Locking Demo Endpoints");
        info.put("description", "Endpoints to demonstrate optimistic and pessimistic locking in JPA");

        Map<String, String> endpoints = new HashMap<>();
        endpoints.put("GET /user-with-version/{id}", "Get user with version information (optimistic locking)");
        endpoints.put("POST /optimistic-conflict/{id}", "Simulate optimistic lock conflict");
        endpoints.put("PUT /pessimistic-update/{id}", "Update user with pessimistic write lock");
        endpoints.put("GET /pessimistic-read/{id}", "Get user with pessimistic read lock");
        endpoints.put("GET /pessimistic-write/{id}", "Get user with pessimistic write lock");
        endpoints.put("GET /by-email-locked?email={email}", "Get user by email with pessimistic lock");
        endpoints.put("GET /by-firstname-locked?firstName={name}", "Get users by first name with pessimistic lock");
        endpoints.put("POST /concurrent-updates/{id}?threads=5&lockType=OPTIMISTIC", "Simulate concurrent updates");
        endpoints.put("GET /info", "Get this information page");

        info.put("endpoints", endpoints);
        info.put("note", "All pessimistic lock endpoints use retry logic with exponential backoff");

        return ResponseEntity.ok(info);
    }
}
