package com.example.demo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

/**
 * MongoDB Configuration
 *
 * This configuration enables MongoDB repositories and auditing capabilities.
 * MongoDB is used for document-based data that complements the PostgreSQL relational data.
 *
 * Use Cases:
 * - UserActivityLog: High-volume time-series data for user actions and API calls
 * - UserPreferences: Flexible user settings and customization (variable schema)
 * - AuditTrail: Immutable compliance and security audit records
 *
 * Configuration:
 * - Connection details are in application.properties
 * - Auto-indexing is enabled for performance
 * - Auditing tracks creation/modification timestamps automatically
 */

@Profile("with-nosql")
@Configuration
@EnableMongoRepositories(basePackages = "com.example.demo.repository.mongo")
@EnableMongoAuditing
public class MongoConfig {

    /*
     * Spring Boot auto-configuration handles:
     * - MongoClient creation from spring.data.mongodb.uri
     * - MongoTemplate bean
     * - Transaction support (if configured)
     *
     * Custom beans can be added here if needed:
     * - Custom converters
     * - Custom validators
     * - Transaction managers
     */
}
