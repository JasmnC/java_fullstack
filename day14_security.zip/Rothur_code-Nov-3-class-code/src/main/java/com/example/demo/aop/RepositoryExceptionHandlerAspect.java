package com.example.demo.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Component;

import java.sql.SQLException;

/**
 * Aspect for handling exceptions in repository layer
 *
 * This aspect intercepts all methods in repository classes and handles:
 * - SQL exceptions
 * - Data access exceptions
 * - General runtime exceptions
 */
@Aspect
@Component
public class RepositoryExceptionHandlerAspect {
    private static final Logger log = LoggerFactory.getLogger(RepositoryExceptionHandlerAspect.class);

    /**
     * Around advice for all methods in repository package
     * Catches and handles exceptions, provides meaningful error messages
     */
    @Around("execution(* com.example.demo.repository..*(..))")
    public Object handleRepositoryExceptions(ProceedingJoinPoint pjp) throws Throwable {
        String methodName = pjp.getSignature().getName();
        String className = pjp.getTarget().getClass().getSimpleName();

        try {
            log.debug("Executing repository method: {}.{}", className, methodName);
            Object result = pjp.proceed();
            log.debug("Successfully executed: {}.{}", className, methodName);
            return result;

        } catch (EmptyResultDataAccessException ex) {
            log.warn("No data found in {}.{}: {}", className, methodName, ex.getMessage());
            throw new RuntimeException("No data found for the given criteria", ex);

        } catch (DataIntegrityViolationException ex) {
            log.error("Data integrity violation in {}.{}: {}", className, methodName, ex.getMessage());
            throw new RuntimeException("Data integrity violation - duplicate or invalid data", ex);

        } catch (DataAccessException ex) {
            log.error("Data access error in {}.{}: {}", className, methodName, ex.getMessage(), ex);
            throw new RuntimeException("Database access error occurred", ex);

        } catch (SQLException ex) {
            log.error("SQL exception in {}.{}: {}", className, methodName, ex.getMessage(), ex);
            throw new RuntimeException("Database operation failed: " + ex.getMessage(), ex);

        } catch (IllegalArgumentException ex) {
            log.warn("Invalid argument in {}.{}: {}", className, methodName, ex.getMessage());
            throw ex; // Re-throw as-is

        } catch (Exception ex) {
            log.error("Unexpected error in {}.{}: {}", className, methodName, ex.getMessage(), ex);
            throw new RuntimeException("Unexpected error in repository operation", ex);
        }
    }
}