package com.example.demo.service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import jakarta.persistence.OptimisticLockException;
import jakarta.persistence.PessimisticLockException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service layer for Spring Data JPA implementation
 *
 * This is the simplest service implementation as Spring Data JPA's
 * JpaRepository already provides all the basic CRUD operations.
 * The service layer here is very thin, but it's still important to have
 * for future business logic and to keep the controller decoupled from
 * the repository layer.
 */
@Service("userServiceJpa")
@Transactional
public class UserServiceJpa implements UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceJpa.class);
    private final UserRepository userRepository;

    public UserServiceJpa(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Create user and evict allUsers cache.
     * The list of all users will be invalidated since a new user was added.
     */
    @Override
    @CacheEvict(value = "allUsers", allEntries = true)
    public User createUser(User user) {
        logger.info("Creating user and evicting allUsers cache");
        // JpaRepository.save() handles both insert and update
        return userRepository.save(user);
    }

    /**
     * Get user by ID with caching.
     * Cache key: "users::{id}"
     * TTL: 30 minutes
     */
    @Override
    @Transactional(readOnly = true)
    @Cacheable(value = "users", key = "#id", unless = "#result == null")
    public Optional<User> getUserById(Long id) {
        logger.info("Cache MISS - Fetching user from database. ID: {}", id);
        // findById is provided by JpaRepository
        return userRepository.findById(id);
    }

    /**
     * Get all users with caching.
     * Cache key: "allUsers"
     * TTL: 10 minutes (shorter because list changes frequently)
     */
    @Override
    @Transactional(readOnly = true)
    @Cacheable(value = "allUsers")
    public List<User> getAllUsers() {
        logger.info("Cache MISS - Fetching all users from database");
        // findAll is provided by JpaRepository
        return userRepository.findAll();
    }

    /**
     * Update user with optimistic locking and retry logic.
     * If an OptimisticLockException occurs (version conflict), it will retry up to 3 times
     * with exponential backoff (100ms, 200ms, 400ms).
     *
     * Cache eviction: Evicts the specific user and all users list from cache.
     */
    @Override
    @Retryable(
            retryFor = {OptimisticLockException.class},
            maxAttempts = 3,
            backoff = @Backoff(delay = 100, multiplier = 2)
    )
    @Caching(evict = {
            @CacheEvict(value = "users", key = "#user.id"),
            @CacheEvict(value = "allUsers", allEntries = true),
            @CacheEvict(value = "userExists", key = "#user.id")
    })
    public User updateUser(User user) {
        if (!userRepository.existsById(user.getId())) {
            throw new RuntimeException("User not found with id: " + user.getId());
        }
        logger.info("Attempting to update user with id: {} (version: {}). Evicting cache.", user.getId(), user.getVersion());
        // save() handles both create and update
        // If another transaction modified this user, OptimisticLockException will be thrown
        return userRepository.save(user);
    }

    /**
     * Recovery method for updateUser when all retry attempts fail.
     * This method is called after the final retry attempt fails.
     */
    @Recover
    public User recoverFromUpdateFailure(OptimisticLockException e, User user) {
        logger.error("Failed to update user after retries. User ID: {}, Version: {}",
                user.getId(), user.getVersion(), e);
        throw new RuntimeException("Unable to update user due to concurrent modification. Please try again.", e);
    }

    /**
     * Delete user and evict from cache.
     * Evicts the user from individual cache, existence cache, and all users list.
     */
    @Override
    @Caching(evict = {
            @CacheEvict(value = "users", key = "#id"),
            @CacheEvict(value = "allUsers", allEntries = true),
            @CacheEvict(value = "userExists", key = "#id")
    })
    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new RuntimeException("User not found with id: " + id);
        }
        logger.info("Deleting user with id: {}. Evicting cache.", id);
        // deleteById is provided by JpaRepository
        userRepository.deleteById(id);
    }

    /**
     * Check if user exists with caching.
     * Cache key: "userExists::{id}"
     * TTL: 15 minutes
     */
    @Override
    @Transactional(readOnly = true)
    @Cacheable(value = "userExists", key = "#id")
    public boolean userExists(Long id) {
        logger.info("Cache MISS - Checking user existence in database. ID: {}", id);
        // existsById is provided by JpaRepository
        return userRepository.existsById(id);
    }

    // ==================== PESSIMISTIC LOCKING METHODS ====================

    /**
     * Update user using pessimistic write lock.
     * This method locks the row during the read, preventing any other transaction
     * from reading or modifying it until this transaction completes.
     * Use this for critical updates where concurrent modifications must be prevented.
     *
     * Cache eviction: Evicts the specific user and all users list from cache.
     *
     * @param id User ID to update
     * @param updatedUser Updated user data
     * @return Updated user
     * @throws RuntimeException if user not found or lock cannot be acquired
     */
    @Retryable(
            retryFor = {PessimisticLockException.class},
            maxAttempts = 3,
            backoff = @Backoff(delay = 100, multiplier = 2)
    )
    @Caching(evict = {
            @CacheEvict(value = "users", key = "#id"),
            @CacheEvict(value = "allUsers", allEntries = true),
            @CacheEvict(value = "userExists", key = "#id")
    })
    public User updateUserWithPessimisticLock(Long id, User updatedUser) {
        logger.info("Attempting to update user with pessimistic lock. ID: {}. Evicting cache.", id);

        // Acquire pessimistic write lock on the user
        User existingUser = userRepository.findByIdWithWriteLock(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));

        // Update fields
        existingUser.setFirstName(updatedUser.getFirstName());
        existingUser.setLastName(updatedUser.getLastName());
        existingUser.setEmail(updatedUser.getEmail());

        // Save with the lock still held
        User savedUser = userRepository.save(existingUser);
        logger.info("Successfully updated user with pessimistic lock. ID: {}", id);
        return savedUser;
    }

    /**
     * Recovery method for pessimistic lock update failures.
     */
    @Recover
    public User recoverFromPessimisticUpdateFailure(PessimisticLockException e, Long id, User updatedUser) {
        logger.error("Failed to acquire pessimistic lock for user update after retries. User ID: {}", id, e);
        throw new RuntimeException("Unable to update user - resource is locked by another process. Please try again.", e);
    }

    /**
     * Get user by ID with pessimistic read lock.
     * This locks the row for reading, preventing writes but allowing other reads.
     * Use when you need to ensure data consistency during a read operation.
     *
     * @param id User ID
     * @return Optional containing the user if found
     */
    @Transactional(readOnly = true)
    public Optional<User> getUserByIdWithReadLock(Long id) {
        logger.info("Fetching user with pessimistic read lock. ID: {}", id);
        return userRepository.findByIdWithReadLock(id);
    }

    /**
     * Get user by ID with pessimistic write lock.
     * This locks the row for updates, preventing all other access.
     * Use when you're about to perform an update operation.
     *
     * @param id User ID
     * @return Optional containing the user if found
     */
    public Optional<User> getUserByIdWithWriteLock(Long id) {
        logger.info("Fetching user with pessimistic write lock. ID: {}", id);
        return userRepository.findByIdWithWriteLock(id);
    }

    /**
     * Get user by email with pessimistic write lock.
     * Useful when you need to ensure email uniqueness during registration/update.
     *
     * @param email User email
     * @return Optional containing the user if found
     */
    public Optional<User> getUserByEmailWithLock(String email) {
        logger.info("Fetching user by email with pessimistic lock. Email: {}", email);
        return userRepository.findByEmailWithLock(email);
    }

    /**
     * Get users by first name with pessimistic write lock.
     * Use when you need to perform bulk operations on users with a specific first name.
     *
     * @param firstName First name to search for
     * @return List of users with the given first name
     */
    public List<User> getUsersByFirstNameWithLock(String firstName) {
        logger.info("Fetching users by first name with pessimistic lock. First name: {}", firstName);
        return userRepository.findByFirstNameWithLock(firstName);
    }
}
