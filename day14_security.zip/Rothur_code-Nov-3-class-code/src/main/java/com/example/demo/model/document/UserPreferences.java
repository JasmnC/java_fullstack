package com.example.demo.model.document;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * UserPreferences - MongoDB Document
 *
 * Stores user-specific settings, UI preferences, and feature flags.
 * This is a flexible document that can evolve as new features are added.
 *
 * Use Cases:
 * - Theme and appearance settings
 * - Notification preferences
 * - Dashboard layout customization
 * - Feature flag toggles
 * - Language and timezone settings
 *
 * Why MongoDB:
 * - Highly variable structure per user (schema-less advantage)
 * - Frequent reads, infrequent writes (perfect for caching)
 * - No SQL joins needed
 * - Easy to add new preference fields without schema migration
 * - One-to-one relationship with PostgreSQL User
 *
 *
 *
 *
 * Server1                  Server3                              Server2
 * Springboot              Redis-cache                             DB
 *
 *
 *
 *
 *
 *
 *
 *
 */
@Document(collection = "user_preferences")
public class UserPreferences implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id; // MongoDB ObjectId

    /**
     * Reference to PostgreSQL User.id
     * Unique index ensures one preferences document per user
     */
    @Indexed(unique = true)
    private Long userId;

    /**
     * UI Theme preference
     * Examples: "light", "dark", "auto"
     */
    private String theme;

    /**
     * Language/locale preference
     * Example: "en-US", "es-ES", "fr-FR"
     */
    private String language;

    /**
     * Timezone preference
     * Example: "America/New_York", "Europe/London", "Asia/Tokyo"
     */
    private String timezone;

    /**
     * Notification preferences
     * Flexible map for various notification channels and frequencies
     */
    private NotificationPreferences notifications;

    /**
     * Dashboard layout configuration
     * Stores widget arrangement, default views, etc.
     */
    private DashboardLayout dashboardLayout;

    /**
     * Feature flags specific to this user
     * Enables/disables experimental or beta features
     */
    private Map<String, Boolean> featureFlags;

    /**
     * Custom user-defined settings
     * Flexible map for any additional preferences
     */
    private Map<String, Object> customSettings;

    /**
     * When preferences were created
     */
    @CreatedDate
    private Instant createdAt;

    /**
     * When preferences were last updated
     */
    @LastModifiedDate
    private Instant lastUpdated;

    /**
     * Version for optimistic locking
     * Incremented on each update to prevent concurrent modification conflicts
     */
    @Version
    private Long version;

    // Nested Classes for structured preferences

    public static class NotificationPreferences implements Serializable {
        private Boolean email;
        private Boolean sms;
        private Boolean push;
        private String frequency; // "realtime", "daily", "weekly"

        public NotificationPreferences() {
        }

        // Getters and Setters

        public Boolean getEmail() {
            return email;
        }

        public void setEmail(Boolean email) {
            this.email = email;
        }

        public Boolean getSms() {
            return sms;
        }

        public void setSms(Boolean sms) {
            this.sms = sms;
        }

        public Boolean getPush() {
            return push;
        }

        public void setPush(Boolean push) {
            this.push = push;
        }

        public String getFrequency() {
            return frequency;
        }

        public void setFrequency(String frequency) {
            this.frequency = frequency;
        }
    }

    public static class DashboardLayout implements Serializable {
        private List<String> widgets; // e.g., ["chart1", "table2", "stats3"]
        private String defaultView; // e.g., "overview", "detailed", "compact"
        private Map<String, Object> customLayout;

        public DashboardLayout() {
        }

        // Getters and Setters

        public List<String> getWidgets() {
            return widgets;
        }

        public void setWidgets(List<String> widgets) {
            this.widgets = widgets;
        }

        public String getDefaultView() {
            return defaultView;
        }

        public void setDefaultView(String defaultView) {
            this.defaultView = defaultView;
        }

        public Map<String, Object> getCustomLayout() {
            return customLayout;
        }

        public void setCustomLayout(Map<String, Object> customLayout) {
            this.customLayout = customLayout;
        }
    }

    // Constructors

    public UserPreferences() {
    }

    public UserPreferences(Long userId) {
        this.userId = userId;
        this.theme = "light";
        this.language = "en-US";
        this.timezone = "UTC";
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public NotificationPreferences getNotifications() {
        return notifications;
    }

    public void setNotifications(NotificationPreferences notifications) {
        this.notifications = notifications;
    }

    public DashboardLayout getDashboardLayout() {
        return dashboardLayout;
    }

    public void setDashboardLayout(DashboardLayout dashboardLayout) {
        this.dashboardLayout = dashboardLayout;
    }

    public Map<String, Boolean> getFeatureFlags() {
        return featureFlags;
    }

    public void setFeatureFlags(Map<String, Boolean> featureFlags) {
        this.featureFlags = featureFlags;
    }

    public Map<String, Object> getCustomSettings() {
        return customSettings;
    }

    public void setCustomSettings(Map<String, Object> customSettings) {
        this.customSettings = customSettings;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Instant lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }
}
