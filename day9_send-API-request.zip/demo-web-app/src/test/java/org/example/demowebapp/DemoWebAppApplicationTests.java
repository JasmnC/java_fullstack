package org.example.demowebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoWebAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
