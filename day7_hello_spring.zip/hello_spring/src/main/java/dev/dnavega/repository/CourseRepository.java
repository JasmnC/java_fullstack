package dev.dnavega.repository;
import dev.dnavega.model.Course;

import java.util.ArrayList;
import java.util.List;

public class CourseRepository implements CrudRepository<Course> {

    @Override
    public List<Course> findAll() {
        List<Course> courses = new ArrayList<>();
        courses = new ArrayList<>();
        Course springBoot = new Course("001", "getting start with spring", "how to ccreate spring app", "2");

        courses.add(springBoot);
        return courses;
    }

}
