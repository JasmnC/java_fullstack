package dev.dnavega.config;

import dev.dnavega.repository.CourseRepository;
import dev.dnavega.service.CourseService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean("courseRepository")
    public CourseRepository getCourseRepositoty() {
        return new CourseRepository();
    }

    @Bean("courseService")
    public CourseService getCourseService() {
        return new CourseService(getCourseRepositoty());
    }
}
