package dev.dnavega.service;

import dev.dnavega.model.Course;
import dev.dnavega.repository.CourseRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CourseService implements CrudService<Course> {

//    private List<Course> courses;

//    public CourseService() {
//        courses = new ArrayList<>();
//        Course springBoot = new Course("001", "getting start with spring", "how to ccreate spring app", "2");
//
//        courses.add(springBoot);
//    }

    private CourseRepository repository;

//    public CourseService(){
//        repository = new CourseRepository();
//    }
    public CourseService(CourseRepository courseRepository) {
        repository = courseRepository;
    }

    @Override
    public List<Course> list() {
//        return courses;
        return repository.findAll();
    }

    @Override
    public Course create(Course course) {
        return null;
    }

    @Override
    public Optional<Course> get(String courseCode) {
        return Optional.empty();
    }

    @Override
    public void update(Course course, String courseCode) {

    }

    @Override
    public void delete(String courseCode) {

    }
}
