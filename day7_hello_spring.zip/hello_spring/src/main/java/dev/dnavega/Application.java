package dev.dnavega;

import dev.dnavega.config.AppConfig;
import dev.dnavega.service.CourseService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {

    public static void main(String[] args){
//        CourseService service = new CourseService();
//        System.out.println(service.list());

        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
        CourseService service =  (CourseService) applicationContext.getBean("courseService");
        System.out.println(service.list());

    }
}
